<?php

namespace Modules\Deces\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DecesDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $this->call([
            DeclarationDecesSeeder::class,
            ActeDecesFromDeclarationsSeeder::class,
        ]);
    }
}
