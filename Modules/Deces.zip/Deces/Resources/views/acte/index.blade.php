@extends('layout.app')
@section('titre')
Actes de décès
@endsection
@section("styles")
<!-- Datatable -->
    <link href="{{ asset('tpl/vendor/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="{{ asset('tpl/wizard/dist/css/style.min.css') }}" rel="stylesheet">

    <style>
        .modal-content {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        .modal-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 0.75rem 0.75rem 0 0;
        }

        .modal-footer {
            border-top: 1px solid #dee2e6;
            border-radius: 0 0 0.75rem 0.75rem;
        }

        .card.border-light {
            border: 1px solid #e9ecef !important;
            border-radius: 0.5rem;
        }
    </style>
@endsection

@section('corps')
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header">
                <h4>Liste des actes de décès</h4>
                <div class="row">
                    <div id="dupcreer">
                        @can('module.acteDeces.generate')
                        <button class="btn btn-sm btn-success mb-2 generate-actes d-none">Générer les actes</button>
                        @endcan
                        @can('module.acteDeces.signature')
                        <button class="btn btn-sm btn-primary mb-2 validate-actes d-none">Valider les actes</button>
                        <button class="btn btn-sm btn-primary mb-2 validate-on-acte d-none">Valider un acte</button>
                        @endcan
                        <button class="btn btn-sm btn-info mb-2 confirmer-documents d-none">Confirmer les dossiers</button>
                        <button class="btn btn-sm btn-warning mb-2 renvoyer-documents d-none">Renvoyer les dossiers</button>
                    </div>
                </div>
            </div>
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <div class="profile-tab">
                            <div class="custom-tab-1">
                                <ul class="nav nav-tabs nav-pills mb-3" id="decesTabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a href="#liste-documents"
                                           class="nav-link active"
                                           id="tab-documents"
                                           data-bs-toggle="tab"
                                           role="tab"
                                           aria-controls="liste-documents"
                                           aria-selected="true">
                                            <i class="fas fa-clipboard-check me-1"></i>
                                            Documents à contrôler
                                        </a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a href="#gestion-actes"
                                           class="nav-link"
                                           id="tab-actes"
                                           data-bs-toggle="tab"
                                           role="tab"
                                           aria-controls="gestion-actes"
                                           aria-selected="false">
                                            <i class="fas fa-tasks me-1"></i>
                                            Gestion des actes
                                        </a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div id="liste-documents" class="tab-pane fade active show">
                                        <div class="pt-3">
                                            <div class="table-responsive">
                                                <table id="table-documents-controle" class="table table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th><input type="checkbox" id="check-all-documents"></th>
                                                            <th>N° Déclaration</th>
                                                            <th>Défunt</th>
                                                            <th>Date décès</th>
                                                            <th>Sexe</th>
                                                            <th>Type Document</th>
                                                            <th>Statut</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($documentsAControler as $dd)
                                                            @php
                                                                $dernierMouvement = null;
                                                                if (isset($dd->mouvements) && $dd->mouvements && $dd->mouvements->count()) {
                                                                    $dernierMouvement = $dd->mouvements->sortByDesc('created_at')->first();
                                                                }
                                                                $codesMouvements = $dd->mouvements->pluck('code_mouvement')->toArray();
                                                                $acteProduit = collect(['MOUV_0014','MOUV_0015','MOUV_0016','MOUV_0017','MOUV_0023'])->intersect($codesMouvements)->isNotEmpty();
                                                                $acteValide = $dd->acte && $dd->acte->statut == 1 && $dd->acte->approbation_pompe_funebre;
                                                                $dejaConfirme = in_array('MOUV_0019', $codesMouvements);
                                                            @endphp
                                                            <tr width="100%" @if($dejaConfirme) style="background: #f5f5f5; color: #aaa;" @endif>
                                                                <td>
                                                                    @if(!$dejaConfirme)
                                                                        <input type="checkbox" class="checkbox-document" value="{{ $dd->code_declaration_deces }}">
                                                                    @else
                                                                        -
                                                                    @endif
                                                                </td>
                                                                <td>{{ $dd->code_declaration_deces }}</td>
                                                                <td>{{ $dd->defunt->nomcomplet() }}</td>
                                                                <td>{{ isset($dd->date_heure_deces) ? date('d/m/Y', strtotime($dd->date_heure_deces)) : '' }}</td>
                                                                <td>{{ $dd->defunt->sexe == "M" ? "Masculin" : "Féminin" }}</td>
                                                                <td>{{ $dd->type_declaration }}</td>
                                                                <td style="width: 15%">
                                                                    @if($dernierMouvement)
                                                                        @if($dernierMouvement->code_mouvement == 'MOUV_0002' || $dernierMouvement->code_mouvement == 'MOUV_2006')
                                                                            <span class="badge light badge-warning" style="font-size: 13px;font-weight:600;">
                                                                                Dossier reçu
                                                                            </span>
                                                                        @else
                                                                            <span class="badge light badge-secondary" style="font-size: 13px;font-weight:600;">
                                                                                {{ $dernierMouvement->lib_mouvement }}
                                                                            </span>
                                                                        @endif

                                                                        @if($dernierMouvement->code_mouvement == 'MOUV_0004')
                                                                            <span class="badge light badge-info" style="font-size: 13px;font-weight:600;">
                                                                                {{ $dernierMouvement->lib_mouvement }}
                                                                            </span>
                                                                        @endif

                                                                        @if($dernierMouvement->code_mouvement == 'MOUV_0016')
                                                                            <span class="badge light badge-success" style="font-size: 13px;font-weight:600;">
                                                                                {{ $dernierMouvement->lib_mouvement }}
                                                                            </span>
                                                                        @endif
                                                                        @if($dernierMouvement->code_mouvement == 'MOUV_0017')
                                                                            <span class="badge light badge-secondary" style="font-size: 13px;font-weight:600;">
                                                                                {{ $dernierMouvement->lib_mouvement}}
                                                                            </span>
                                                                        @endif
                                                                        <br>
                                                                        @if($dernierMouvement->observation)
                                                                            <small>Observation : {{ $dernierMouvement->observation }}</small>
                                                                        @endif
                                                                        @if($dernierMouvement->motif_renvoi)
                                                                            <br><small>Motif : {{ $dernierMouvement->motif_renvoi }}</small>
                                                                        @endif
                                                                    @else
                                                                        {{-- <span class="badge light badge-secondary" style="font-size: 13px;font-weight:600;">
                                                                            En cours
                                                                        </span> --}}

                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    <div class="btn-group btn-group-xs">
                                                                        <a href="{{ route('declarationDeces.show', $dd->code_declaration_deces) }}"
                                                                           class="btn btn-info shadow btn-xs sharp me-1" title="Voir détail">
                                                                            <i class="fas fa-eye"></i>
                                                                        </a>
                                                                        <a href="{{ route('declarationDeces.etat', $dd->code_declaration_deces) }}"
                                                                           target="_blank" class="btn btn-warning shadow btn-xs sharp me-1" title="Voir la déclaration ou le certificat">
                                                                            <i class="fas fa-file-pdf"></i>
                                                                        </a>
                                                                        @if(isset($dd->requisition) && $dd->requisition || isset($dd->jugement) && $dd->jugement)
                                                                                {{-- <a href="{{ route('requisition.show', $dd->requisition->code_requisition) }}" target="_blank" class="btn btn-success shadow btn-xs sharp me-1" title="Voir la réquisition">
                                                                                    <i class="fas fa-file-contract"></i>
                                                                                </a> --}}

                                                                                <a href="{{ route('tribunal.voir_document', ['type' => "deces", 'id' =>  $dd->code_declaration_deces]) }}"
                                                                                    class="btn btn-info btn-xs text-start me-1" title="Télécharger {{ $dd->requisition ? "la requisition importée" : "le jugement importé" }} par le tribunal">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            @endif
                                                                        @if(!$dejaConfirme)
                                                                        <button class="btn btn-success shadow btn-xs sharp me-1 btn-confirmer-document"
                                                                                data-id="{{ $dd->code_declaration_deces }}" title="Confirmer le dossier">
                                                                            <i class="fas fa-check"></i>
                                                                        </button>

                                                                        <button class="btn btn-warning shadow btn-xs sharp btn-renvoyer-document"
                                                                                data-id="{{ $dd->code_declaration_deces }}" title="Renvoyer">
                                                                            <i class="fas fa-undo"></i>
                                                                        </button>
                                                                        @endif
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                    <tfoot>
                                                        <th>#</th>
                                                        <th>N° Déclaration</th>
                                                        <th>Défunt</th>
                                                        <th>Date décès</th>
                                                        <th>Sexe</th>
                                                        <th>Type Document</th>
                                                        <th>Statut</th>
                                                        <th>Actions</th>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="gestion-actes" class="tab-pane fade">
                                        <div class="pt-3">
                                            <div class="table-responsive">
                                                <table id="table-actes-gestion" class="table table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th><input type="checkbox" id="check-all-actes"></th>
                                                            <th>N° Acte</th>
                                                            <th>Défunt</th>
                                                            <th>Date décès</th>
                                                            <th>Sexe</th>
                                                            <th>Statut</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($actesGestion as $dd)
                                                            @php
                                                                $dernierMouvement = null;
                                                                if (isset($dd->mouvements) && $dd->mouvements && $dd->mouvements->count()) {
                                                                    $dernierMouvement = $dd->mouvements->sortByDesc('created_at')->first();
                                                                }
                                                                $codesMouvements = $dd->mouvements->pluck('code_mouvement')->toArray();
                                                                $acteGenere = $dd->acte != null;
                                                                $acteValide = $dd->acte && $dd->acte->approbation_pompe_funebre;
                                                            @endphp
                                                            <tr width="100%" @if($acteValide) style="background: #f5f5f5; color: #aaa;" @endif>
                                                                <td>
                                                                    @if($acteValide)
                                                                        <span class="badge bg-success" style="font-size: 13px;font-weight:600;">Acte déjà validé</span>
                                                                    @elseif($acteGenere)
                                                                        <input type="checkbox" class="checkbox-acte" value="{{ $dd->code_declaration_deces }}-1" disabled>
                                                                    @else
                                                                        <input type="checkbox" class="checkbox-acte" value="{{ $dd->code_declaration_deces }}-0">
                                                                    @endif
                                                                </td>
                                                                <td>{{ $dd->acte ? $dd->acte->code_acte_deces : '//' }}</td>
                                                                <td>{{ $dd->defunt->nomcomplet() }}</td>
                                                                <td>{{ isset($dd->date_heure_deces) ? date('d/m/Y', strtotime($dd->date_heure_deces)) : '' }}</td>
                                                                <td>{{ $dd->defunt->sexe == "M" ? "Masculin" : "Féminin" }}</td>
                                                                <td style="width: 15%">
                                                                    @if(!$dd->acte)
                                                                        <span class="badge badge-danger">En attente de génération de l'acte</span>
                                                                    @elseif($dd->acte && !$dd->acte->approbation_pompe_funebre)
                                                                        <span class="badge badge-warning">Acte généré, en attente de validation de l'officier</span>
                                                                    @elseif($dd->acte && $dd->acte->approbation_pompe_funebre && isset($dernierMouvement) && $dernierMouvement->code_mouvement == "MOUV_0016")
                                                                        <span class="badge badge-success">Acte rétiré</span>
                                                                    @elseif($dd->acte && $dd->acte->approbation_pompe_funebre && isset($dernierMouvement) && $dernierMouvement->code_mouvement == "MOUV_0017")
                                                                        <span class="badge badge-danger">Acte annulé</span>
                                                                    @elseif($dd->acte && $dd->acte->approbation_pompe_funebre)
                                                                        <span class="badge badge-info">Acte validé, non rétiré</span>
                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    <div class="btn-group btn-group-xs">
                                                                        @if(!$dd->acte)
                                                                            @can('module.acteDeces.generate')
                                                                                <button class="btn btn-success shadow btn-xs sharp me-1 btn-generer-single"
                                                                                        data-id="{{ $dd->code_declaration_deces }}" title="Générer acte">
                                                                                    <i class="fas fa-file-alt"></i>
                                                                                </button>
                                                                            @endcan

                                                                            @if($dd->type_declaration == "CERTIFICAT DE NON INSCRIPTION")
                                                                                <a href="{{ route('certificatNonInscriptionDeces.displayCertificat',$dd->code_declaration_deces) }}" target="_blank" class="btn btn-warning shadow btn-xs sharp me-1" title="Voir document"><i class="fas fa-print"></i></a>
                                                                                @if($dd->requisition != null)
                                                                                <a href="{{ route('tribunal.voir_document', ['type' => 'deces', 'id' => $dd->code_declaration_deces]) }}"
                                                                                    class="btn btn-info btn-xs text-start me-1" title="Télécharger le document importé">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                                @endif
                                                                            @else
                                                                                <a href="{{ route('declarationDeces.etat',$dd->code_declaration_deces) }}" target="_blank" class="btn btn-warning shadow btn-xs sharp me-1" title="Voir document"><i class="fas fa-print"></i></a>
                                                                            @endif
                                                                            {{-- <a href="{{ route('declarationDeces.etat',$dd->code_declaration_deces) }}" target="_blank" class="btn btn-warning shadow btn-xs sharp me-1" title="Voir document"><i class="fas fa-print"></i></a> --}}
                                                                        @elseif($dd->acte && !$dd->acte->approbation_pompe_funebre)
                                                                            <a href="{{ route('acteDeces.print.acte',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-primary shadow btn-xs sharp me-1"
                                                                               title="Voir l'acte">
                                                                                <i class="fas fa-eye"></i>
                                                                            </a>
                                                                            @can('module.acteDeces.signature')
                                                                                <button class="btn btn-primary shadow btn-xs sharp me-1 btn-validate-single"
                                                                                        data-id="{{ $dd->code_declaration_deces }}" title="Valider acte">
                                                                                    <i class="fas fa-check-circle"></i>
                                                                                </button>
                                                                            @endcan
                                                                        @elseif($dd->acte && $dd->acte->approbation_pompe_funebre && isset($dernierMouvement) && $dernierMouvement->code_mouvement == "MOUV_0016")
                                                                            <a href="{{ route('acteDeces.print.acte',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-primary shadow btn-xs sharp me-1"
                                                                               title="Voir l'acte">
                                                                                <i class="fas fa-eye"></i>
                                                                            </a>
                                                                            <a href="{{ route('acteDeces.displayCopie',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-info shadow btn-xs sharp me-1"
                                                                               title="Voir copie">
                                                                                <i class="fas fa-copy"></i>
                                                                            </a>
                                                                            <a href="{{ route('acteDeces.displayExtrait',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-warning shadow btn-xs sharp me-1"
                                                                               title="Voir extrait">
                                                                                <i class="fas fa-file-alt"></i>
                                                                            </a>
                                                                            @if(!isset($dernierMouvement) || $dernierMouvement->code_mouvement != "MOUV_0016")
                                                                                <button class="btn btn-secondary shadow btn-xs sharp btn-retrait-acte"
                                                                                        data-id="{{ $dd->acte->code_acte_deces }}" title="Enregistrer le retrait">
                                                                                    <i class="fas fa-archive"></i>
                                                                                </button>
                                                                            @endif
                                                                        @elseif($dd->acte && $dd->acte->approbation_pompe_funebre && isset($dernierMouvement) && $dernierMouvement->code_mouvement == "MOUV_0017")
                                                                            <a href="{{ route('acteDeces.print.acte',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-primary shadow btn-xs sharp me-1"
                                                                               title="Voir l'acte">
                                                                                <i class="fas fa-eye"></i>
                                                                            </a>
                                                                        @elseif($dd->acte && $dd->acte->approbation_pompe_funebre)
                                                                            <a href="{{ route('acteDeces.print.acte',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-primary shadow btn-xs sharp me-1"
                                                                               title="Voir l'acte">
                                                                                <i class="fas fa-eye"></i>
                                                                            </a>
                                                                            <a href="{{ route('acteDeces.displayCopie',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-info shadow btn-xs sharp me-1"
                                                                               title="Voir copie">
                                                                                <i class="fas fa-copy"></i>
                                                                            </a>
                                                                            <a href="{{ route('acteDeces.displayExtrait',$dd->code_declaration_deces) }}"
                                                                               target="_blank"
                                                                               class="btn btn-warning shadow btn-xs sharp me-1"
                                                                               title="Voir extrait">
                                                                                <i class="fas fa-file-alt"></i>
                                                                            </a>
                                                                            @if(!isset($dernierMouvement) || $dernierMouvement->code_mouvement != "MOUV_0016")
                                                                                <button class="btn btn-danger shadow btn-xs sharp btn-retrait-acte"
                                                                                        data-id="{{ $dd->acte->code_acte_deces }}" title="Enregistrer le retrait">
                                                                                    <i class="fas fa-archive"></i>
                                                                                </button>
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                    <tfoot>
                                                        <th>#</th>
                                                        <th>N° Acte</th>
                                                        <th>Défunt</th>
                                                        <th>Date décès</th>
                                                        <th>Sexe</th>
                                                        <th>Statut</th>
                                                        <th>Actions</th>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modal-acte" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="module-title">  </span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12 text-center">
                        <h4 id="certificat"></h4>
                    </div>
                    @if($registre != null)
                        <div class="mb-2 col-md-6 cacher">
                            <label class="form-label">Régistre <span class="text-danger">*</span></label>
                            <input id="code_declaration_deces_generate" type="text" class="form-control cacher" readonly value="{{ $registre->code_registre }}">
                        </div>
                        <div class="mb-2 col-md-6 cacher">
                            <label class="form-label">Numéro déclaration deces <span class="text-danger">*</span></label>
                            <input id="code_declaration_deces" type="text" class="form-control" class="form-control">
                        </div>
                    @else
                    <label class="form-label cacher"> <span class="text-danger">Aucun registre disponible</span></label>
                    @endif
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-primary light generate cacher">Valider</button>
                <button type="button" class="btn btn-sm btn-danger light" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>

{{-- DEBUT MODAL RECHERCHE ACTE DE deces --}}
<div class="modal fade" id="modal-search-acte" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rechercher</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Nom(s) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control"lass="form-control"  placeholder="" id="nom_recherche" required>
                    </div>
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Prénom(s)</label>
                        <input type="text" class="form-control"  placeholder="" id="prenom_recherche">
                    </div>
                </div>
                <div class="row">

                    <div class="mb-2 col-md-6">
                        <label class="form-label">Lieu de deces </label>
                        <input type="tel" class="form-control"  id="lieu_recherche">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info text-white" id="rechercher">Rechercher</button>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Résultat de la recherche</h4>
                            </div>
                            <div class="card-body">
                                <div id="resultatrech"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL RECHERCHE ACTE DE NAISSACE --}}

{{-- DEBUT MODAL VALIDATION ACTE DE deces --}}
<div class="modal fade" id="modal-validate-acte" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Validation de l'acte de deces</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="mb-2 col-md-6">
                        <input type="hidden" id="code_declaration_deces_validate">
                        <input type="hidden" id="validation_type">
                        <label class="form-label">Code de validation<span class="text-danger">*</span></label>
                        <input type="text" class="form-control"lass="form-control"  placeholder="" id="otp_approbation_pompe_funebre" required>
                    </div>
                    <span class="text-success"><i>Veuillez saisir le code de validation reçu par SMS.</i> </span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-info btn-sm text-white" id="btn-validate">Valider</button>
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL VALIDATION ACTE DE NAISSACE --}}
{{-- DEBUT MODAL RETRAIT ACTE DE deces --}}
<div class="modal fade" id="modal-retrait-acte" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Retrait de l'acte de deces</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Numéro de l'acte<span class="text-danger">*</span></label>
                        <input type="text" id="code_acte" class="form-control" readonly>
                        <input type="hidden" id="lecode_acte_deces">
                    </div>
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Nom de l'intéressé<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="" id="nom_interesse" required style="text-transform: uppercase;">
                    </div>
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Prénom de l'intéressé<span class="text-danger"></span></label>
                        <input type="text" class="form-control" placeholder="" id="prenom_interesse" style="text-transform: capitalize;">
                    </div>
                    <div class="mb-2 col-md-6">
                        <label class="form-label">Téléphone de l'intéressé<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="" id="telephone_interesse" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-info btn-sm text-white" id="btn-retrait">Valider</button>
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL RETRAIT ACTE DE NAISSACE --}}

{{-- DEBUT RENVOIS DECLARATION --}}
<div class="modal fade" id="modal-declaration-send-back" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="module-title"> Renvoyer le document</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Document n°</label>
                        <input type="text" readonly class="form-control"  placeholder="" id="codedeclarationback">
                        <input type="hidden" class="form-control" id="codemouvementdeces">
                    </div>

                    <div class="mb-2 col-md-12">
                        <label class="form-label">Motif du renvoi <span class="text-danger">*</span></label>
                        <select id="motif_renvoi" name="motif_renvoi" class="form-control" required>
                            <option value="" disabled selected>Selectionner</option>
                            <option value="erreur materielle">Erreur matérielle</option>
                            <option value="Ajouter nom/prenom">Ajouter nom/prénom</option>
                            <option value="rectifier nom/prenom">Rectifier nom/prénom</option>
                        </select>
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation</label>
                        <textarea id="observation" cols="96" rows="5"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-info btn-sm text-white btn-send-back" id="btn-send-back">Renvoyer</button>
                <button type="submit" class="btn btn-info btn-sm text-white btn-edit-send-back" id="btn-edit-send-back">Modifier</button>
                <button type="submit" class="btn btn-warning btn-sm text-white btn-delete-send-back" id="btn-delete-send-back">Annuler le renvoie</button>

                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN RENVOIS DECLARATION --}}

{{-- DEBUT MODAL CONFIRMATION DOSSIERS EN GROUPE --}}
<div class="modal fade" id="modal-confirmation-dossiers-bulk" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmation des dossiers sélectionnés</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Information :</strong> Cette action va confirmer que tous les dossiers sélectionnés sont conformes et prêts pour la génération des actes de deces.
                </div>
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation (optionnel)</label>
                        <textarea id="observation-confirmation-bulk" class="form-control" rows="3" placeholder="Ajoutez une observation pour tous les dossiers..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success btn-sm text-white" id="btn-confirmer-bulk-final">Confirmer</button>
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Annuler</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL CONFIRMATION DOSSIERS EN GROUPE --}}

{{-- DEBUT MODAL ANNULATION ACTE --}}
<div class="modal fade" id="modal-annulation-acte" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Annulation de l'acte</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Attention :</strong> Cette action va annuler définitivement l'acte de deces. Cette opération est irréversible.
                </div>
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Code de la déclaration</label>
                        <input type="text" readonly class="form-control" id="code-declaration-annulation">
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Motif de l'annulation <span class="text-danger">*</span></label>
                        <select id="motif-annulation" class="form-control" required>
                            <option value="" disabled selected>Sélectionner un motif</option>
                            <option value="Erreur matérielle">Erreur matérielle</option>
                            <option value="Fausse déclaration">Fausse déclaration</option>
                            <option value="Documentation insuffisante">Documentation insuffisante</option>
                            <option value="Jugement de tribunal">Jugement de tribunal</option>
                            <option value="Autre">Autre</option>
                        </select>
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation</label>
                        <textarea id="observation-annulation" class="form-control" rows="3" placeholder="Détails sur l'annulation..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger btn-sm text-white" id="btn-annuler-final">Annuler l'acte</button>
                <button type="button" class="btn btn-sm btn-secondary text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL ANNULATION ACTE --}}

{{-- MODAL RENVOI EN GROUPE --}}
<div class="modal fade" id="modal-renvoi-dossiers-bulk" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Renvoi des dossiers sélectionnés</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Attention :</strong> Cette action va renvoyer tous les dossiers sélectionnés à l'institution précédente.
                </div>
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Motif du renvoi <span class="text-danger">*</span></label>
                        <select id="motif-renvoi-bulk" class="form-control" required>
                            <option value="" disabled selected>Selectionner</option>
                            <option value="erreur materielle">Erreur matérielle</option>
                            <option value="Ajouter nom/prenom">Ajouter nom/prénom</option>
                            <option value="rectifier nom/prenom">Rectifier nom/prénom</option>
                        </select>
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation</label>
                        <textarea id="observation-renvoi-bulk" class="form-control" rows="3" placeholder="Ajoutez une observation pour tous les dossiers..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-warning btn-sm text-white" id="btn-renvoyer-bulk-final">Renvoyer</button>
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Annuler</button>
            </div>
        </div>
    </div>
</div>

{{-- MODAL ANNULATION EN GROUPE --}}
<div class="modal fade" id="modal-annulation-actes-bulk" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Annulation des actes sélectionnés</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Attention :</strong> Cette action va annuler définitivement tous les actes sélectionnés. Cette opération est irréversible.
                </div>
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Motif de l'annulation <span class="text-danger">*</span></label>
                        <select id="motif-annulation-bulk" class="form-control" required>
                            <option value="" disabled selected>Sélectionner un motif</option>
                            <option value="Erreur matérielle">Erreur matérielle</option>
                            <option value="Fausse déclaration">Fausse déclaration</option>
                            <option value="Documentation insuffisante">Documentation insuffisante</option>
                            <option value="Jugement de tribunal">Jugement de tribunal</option>
                            <option value="Autre">Autre</option>
                        </select>
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation</label>
                        <textarea id="observation-annulation-bulk" class="form-control" rows="3" placeholder="Détails sur l'annulation..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger btn-sm text-white" id="btn-annuler-bulk-final">Annuler les actes</button>
                <button type="button" class="btn btn-sm btn-secondary text-white" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>

{{-- DEBUT MODAL CONFIRMATION DOSSIER (singleton) --}}
<div class="modal fade" id="modal-confirmation-dossier" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmation du dossier</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Information :</strong> Cette action va confirmer que le dossier est conforme et prêt pour la génération de l'acte de deces.
                </div>
                <div class="row">
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Code de la déclaration</label>
                        <input type="text" readonly class="form-control" id="code-declaration-confirmation">
                    </div>
                    <div class="mb-2 col-md-12">
                        <label class="form-label">Observation (optionnel)</label>
                        <textarea id="observation-confirmation" class="form-control" rows="3" placeholder="Ajoutez une observation..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success btn-sm text-white" id="btn-confirmer-final">Confirmer</button>
                <button type="button" class="btn btn-sm btn-danger text-white" data-bs-dismiss="modal">Annuler</button>
            </div>
        </div>
    </div>
</div>
{{-- FIN MODAL CONFIRMATION DOSSIER --}}

<!-- Modal de suivi génération acte single -->
<div class="modal fade" id="modal-generer-single" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title d-flex align-items-center">
                    <i class="fa fa-plus-circle me-2"></i>
                    Génération d'acte de décès
                </h5>
                <button type="button" class="btn-close btn-close-dark" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="generer-single-message" class="text-center mb-4"></div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">
                            <i class="fa fa-book me-1"></i>
                            Registre <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fa fa-hashtag"></i>
                            </span>
                            <input id="code_registre_deces"
                                   type="text"
                                   class="form-control"
                                   readonly
                                   value="REG_02">
                        </div>
                        <small class="form-text text-muted">Registre automatiquement sélectionné</small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">
                            <i class="fa fa-file-text me-1"></i>
                            Numéro de la déclaration <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fa fa-barcode"></i>
                            </span>
                            <input id="generer-single-code"
                                   type="text"
                                   class="form-control"
                                   placeholder="Code de déclaration"
                                   readonly>
                        </div>
                        <small class="form-text text-muted">Numéro de la déclaration</small>
                    </div>

                    <div class="col-12">
                        <div class="card border-light">
                            <div class="card-body">
                                <h6 class="card-title text-primary">
                                    <i class="fa fa-exclamation-triangle me-1"></i>
                                    Informations importantes
                                </h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="mb-1">
                                        <i class="fa fa-check text-success me-2"></i>
                                        L'acte sera généré avec un code unique
                                    </li>
                                    <li class="mb-1">
                                        <i class="fa fa-check text-success me-2"></i>
                                        Un feuillet de registre sera créé automatiquement pour la production de l'acte
                                    </li>
                                    <li class="mb-1">
                                        <i class="fa fa-check text-success me-2"></i>
                                        L'acte sera en attente de la validation par l'officier d'état civil
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary" id="btn-generer-single-confirm">
                    <i class="fa fa-cog me-1"></i>
                    Générer l'acte
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fa fa-times me-1"></i>
                    Annuler
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de validation OTP -->
<div class="modal fade" id="modal-validate-otp" tabindex="-1">
    <div class="modal-dialog">
        <form id="form-validate-otp">
            @csrf
            <input type="hidden" id="otp_code_declaration_deces" name="code_declaration_deces">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Validation de l'acte</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label for="otp_approbation_pompe_funebre" class="form-label">Code OTP reçu</label>
                    <input type="text" class="form-control" id="otp_approbation_pompe_funebre" name="otp_approbation_pompe_funebre" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Valider</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection
@section("scripts")
<!-- Datatable -->
    <script src="{{ asset('tpl/vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('tpl/js/plugins-init/datatables.init.js') }}"></script>
    <script>



    var codesDocuments = [];
    var codesActes = [];
    var actesGeneres = [];
    var actesNonGeneres = [];

    // Initialisation des DataTables
    $('#table-documents-controle').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
        }
    });
    $('#table-actes-gestion').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
        }
    });
    $('#table-actes-annules').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
        }
    });
    $(function() {

    // Gestion des checkboxes pour les documents à contrôler
    $("#check-all-documents").on("change", function() {
        if ($(this).is(":checked")) {
            $(".checkbox-document").prop("checked", true);
            codesDocuments = [];
            $(".checkbox-document:checked").each(function() {
                codesDocuments.push($(this).val());
            });
        } else {
            $(".checkbox-document").prop("checked", false);
            codesDocuments = [];
        }
        updateDocumentButtons();
    });
    $(".checkbox-document").on("change", function() {
        codesDocuments = [];
        $(".checkbox-document:checked").each(function() {
            codesDocuments.push($(this).val());
        });
        updateDocumentButtons();
    });

    // Gestion des checkboxes pour les actes transcrits
    $("#check-all-actes").on("change", function() {
        if ($(this).is(":checked")) {
            $(".checkbox-acte").prop("checked", true);
            codesActes = [];
            actesGeneres = [];
            actesNonGeneres = [];
            $(".checkbox-acte:checked").each(function() {
                var value = $(this).val();
                codesActes.push(value.split('-')[0]);
                if (value.split('-')[1] == '1') {
                    actesGeneres.push(value.split('-')[0]);
                } else {
                    actesNonGeneres.push(value.split('-')[0]);
                }
            });
        } else {
            $(".checkbox-acte").prop("checked", false);
            codesActes = [];
            actesGeneres = [];
            actesNonGeneres = [];
        }
        updateActeButtons();
    });
    $(".checkbox-acte").on("change", function() {
        codesActes = [];
        actesGeneres = [];
        actesNonGeneres = [];
        $(".checkbox-acte:checked").each(function() {
            var value = $(this).val();
            codesActes.push(value.split('-')[0]);
            if (value.split('-')[1] == '1') {
                actesGeneres.push(value.split('-')[0]);
            } else {
                actesNonGeneres.push(value.split('-')[0]);
            }
        });
        updateActeButtons();
    });

    // Mise à jour des boutons pour les documents
    function updateDocumentButtons() {
        if (codesDocuments.length > 0) {
            $(".confirmer-documents").removeClass("d-none");
            $(".renvoyer-documents").removeClass("d-none");
        } else {
            $(".confirmer-documents").addClass("d-none");
            $(".renvoyer-documents").addClass("d-none");
        }
    }

    // Mise à jour des boutons pour les actes
    function updateActeButtons() {
        if (actesNonGeneres.length > 0) {
            $(".generate-actes").removeClass("d-none");
        } else {
            $(".generate-actes").addClass("d-none");
        }
        if (actesGeneres.length > 0) {
            $(".validate-actes").removeClass("d-none");
        } else {
            $(".validate-actes").addClass("d-none");
        }
    }

    // Confirmation d'un document individuel
    $(".btn-confirmer-document").on("click", function() {
        var codeDeclaration = $(this).data('id');
        $("#code-declaration-confirmation").val(codeDeclaration);
        $("#observation-confirmation").val('');
        $("#modal-confirmation-dossier").modal('show');
    });

    // Confirmation de plusieurs documents
    $(".confirmer-documents").on("click", function(){
        if(codesDocuments.length == 0){
            flashAlert("Attention", "warning", "Veuillez sélectionner au moins un document à confirmer.");
            return;
        }
        $("#modal-confirmation-dossiers-bulk").modal('show');
    });

    // Renvoi d'un document individuel
    $(".btn-renvoyer-document").on("click", function(){
        var codeDeclaration = $(this).data('id');
        $("#codedeclarationback").val(codeDeclaration);
        $("#motif_renvoi").val("");
        $("#observation").val("");
        $("button.btn-send-back").removeClass("d-none");
        $("button.btn-edit-send-back").addClass("d-none");
        $("button.btn-delete-send-back").addClass("d-none");
        $("#modal-declaration-send-back").modal("show");
    });

    // Renvoi de plusieurs documents
    $(".renvoyer-documents").on("click", function(){
        if(codesDocuments.length == 0){
            flashAlert("Attention", "warning", "Veuillez sélectionner au moins un document à renvoyer.");
            return;
        }
        $("#modal-renvoi-dossiers-bulk").modal('show');
    });

    // Annulation d'un acte individuel
    $(".btn-annuler-acte").on("click", function(){
        var codeDeclaration = $(this).data('id');
        $("#code-declaration-annulation").val(codeDeclaration);
        $("#modal-annulation-acte").modal('show');
    });
    $("#btn-annuler-final").on("click", function(){
        var codeDeclaration = $("#code-declaration-annulation").val();
        var motif = $("#motif-annulation").val();
        var observation = $("#observation-annulation").val();
        if(!motif){
            flashAlert("ALERTE","error",'Veuillez sélectionner un motif d\'annulation');
            return;
        }
        $.ajax({
            url: "{{ route('acteDeces.annuler') }}",
            type: 'POST',
            data: {
                code_declaration_deces: codeDeclaration,
                motif: motif,
                observation: observation,
                _token: '{{ csrf_token() }}'
            },
            success: function(resp){
                if(resp.code == "200"){
                    let msg = Array.isArray(resp.message) ? resp.message[0] : (typeof resp.message === 'object' && resp.message.reponse) ? resp.message.reponse : resp.message;
                    flashAlert("Réponse","success",msg);
                    $('#modal-annulation-acte').modal('hide');
                    setTimeout(()=>location.reload(), 1000);
                }else{
                    let msg = Array.isArray(resp.message) ? resp.message[0] : resp.message;
                    flashAlert("Réponse","error",msg);
                }
            },
            error: function(xhr){
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de l\'annulation de l\'acte';
                flashAlert("Erreur","error",msg);
            }
        });
    });



    // Validation d'actes en lot
    $("button.validate-actes").on("click", function(){
        if(actesGeneres.length > 0){
            var url = "{{ route('acteDeces.send.otp.bulk') }}";
            var data = {codes:actesGeneres};
            $.post(url,data,function(response){
            console.log(response);
            if(response.code == "200"){

                $(".over-loader-page").fadeOut(600);
                $("#validation_type").val("bulk");

                $("#modal-validate-acte").modal('show');

            }else{
                $(".over-loader-page").fadeOut(600);
                //notification("error",response.message);
                var outString = "<ul>";
                for (const [key, value] of Object.entries(response.message))
                {
                outString+= `<li style='text-align:left;color:red; list-style:disc !important; font-size:12px'>${value}</li>`;
                }
                outString += "</ul>";
                 flashAlert("ALERTE","error",outString);
                //flashAlert("Une erreur est suvernue","error",outString);

            }
        });
        }
        return false;
    });

    // Validation OTP (singleton ou bulk)
    $("#btn-validate").on("click", function(){
        var code_declaration_deces = $("#code_declaration_deces_validate").val();
        var validation_type = $("#validation_type").val();
        var otp_approbation_pompe_funebre = $("#otp_approbation_pompe_funebre").val();
        var inputs = {
            codes : actesGeneres,
            code_declaration_deces: code_declaration_deces,
            otp_approbation_pompe_funebre: otp_approbation_pompe_funebre
        };
        if(validation_type=="simple"){
            $.ajax({
                url: "{{ route('acteDeces.validate.otp') }}",
                type: 'POST',
                data: {
                    code_declaration_deces: inputs.code_declaration_deces,
                    otp_approbation_pompe_funebre: inputs.otp_approbation_pompe_funebre
                },
                success: function(response){
                    let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
                    flashAlert("Réponse","success",msg);
                    $('#modal-validate-acte').modal('hide');
                    setTimeout(()=>location.reload(), 1000);
                },
                error: function(xhr){
                    let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de la validation de l\'acte';
                    flashAlert("Réponse","error",msg);
                }
            });
        }else{
            $.ajax({
                url: "{{ route('acteDeces.validate.otp.bulk') }}",
                type: 'POST',
                data: {
                    codes: inputs.codes,
                    otp_approbation_pompe_funebre: inputs.otp_approbation_pompe_funebre
                },
                success: function(response){
                    let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
                    flashAlert("Réponse","success",msg);
                    $('#modal-validate-acte').modal('hide');
                    setTimeout(()=>location.reload(), 1000);
                },
                error: function(xhr){
                    let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de la validation des actes';
                    flashAlert("Réponse","error",msg);
                }
            });
        }
        return false;
    });

    // Renvoi individuel (modale)
    $("#btn-send-back").on("click", function(){
        var cdn = $("#codedeclarationback").val();
        var motif = $("#motif_renvoi").val();
        var observation = $("#observation").val();
        var route = "{{ route('acteDeces.renvoyer') }}";
        var data = {
            code_declaration_deces: cdn,
            motif_renvoi: motif,
            observation: observation
        };
        $.post(route, data, function(response){
            let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
            flashAlert("Réponse","success",msg);
            $('#modal-declaration-send-back').modal('hide');
            setTimeout(()=>location.reload(), 1000);
        }).fail(function(xhr){
            let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors du renvoi du dossier';
            flashAlert("Réponse","error",msg);
        });
        return false;
    });

    // Gestion des onglets
    $('a[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
        // Réinitialiser les sélections lors du changement d'onglet
        codesDocuments = [];
        codesActes = [];
        actesGeneres = [];
        actesNonGeneres = [];
        $(".checkbox-document").prop("checked", false);
        $(".checkbox-acte").prop("checked", false);
        $("#check-all-documents").prop("checked", false);
        $("#check-all-actes").prop("checked", false);
        updateDocumentButtons();
        updateActeButtons();
    });

    // Remplacement du JS de confirmation groupée
    $("#btn-confirmer-bulk-final").on("click", function(){
        var observation = $("#observation-confirmation-bulk").val();
        $.ajax({
            url: "{{ route('acteDeces.confirmer.bulk') }}",
            type: 'POST',
            data: {
                codes: codesDocuments,
                observation: observation,
                _token: '{{ csrf_token() }}'
            },
            success: function(response){
                let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
                flashAlert("Réponse","success",msg);
                $('#modal-confirmation-dossiers-bulk').modal('hide');
                setTimeout(()=>location.reload(), 1000);
            },
            error: function(xhr){
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de la confirmation des documents';
                flashAlert("Réponse","error",msg);
            }
        });
    });

    // Remplacement du JS de renvoi groupé
    $("#btn-renvoyer-bulk-final").on("click", function(){
        var motif = $("#motif-renvoi-bulk").val();
        var observation = $("#observation-renvoi-bulk").val();
        if(!motif){
            let msg = 'Veuillez sélectionner un motif de renvoi';
            flashAlert("ALERTE","error",msg);
            return;
        }
    $.ajax({
            url: "{{ route('acteDeces.renvoyer.bulk') }}",
            type: 'POST',
            data: {
                codes: codesDocuments,
                motif_renvoi: motif,
                observation: observation,
                _token: '{{ csrf_token() }}'
            },
            success: function(response){
                let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
                flashAlert("Réponse","success",msg);
                $('#modal-renvoi-dossiers-bulk').modal('hide');
                setTimeout(()=>location.reload(), 1000);
            },
            error: function(xhr){
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors du renvoi des documents';
                flashAlert("Réponse","error",msg);
            }
        });
    });

    // Ajout du JS pour l'annulation groupée
    $(".annuler-actes").on("click", function(){
        if(actesGeneres.length == 0){
            flashAlert("Attention", "warning", "Veuillez sélectionner au moins un acte à annuler.");
            return;
        }
        $("#modal-annulation-actes-bulk").modal('show');
    });
    $("#btn-annuler-bulk-final").on("click", function(){
        var motif = $("#motif-annulation-bulk").val();
        var observation = $("#observation-annulation-bulk").val();
        if(!motif){
            let msg = 'Veuillez sélectionner un motif d\'annulation';
            flashAlert("ALERTE","error",msg);
            return;
        }
        $.ajax({
            url: "{{ route('acteDeces.annuler.bulk') }}",
            type: 'POST',
            data: {
                codes: actesGeneres,
                motif: motif,
                observation: observation,
                _token: '{{ csrf_token() }}'
            },
            success: function(response){
                let msg = Array.isArray(response.message) ? response.message[0] : (typeof response.message === 'object' && response.message.reponse) ? response.message.reponse : response.message;
                flashAlert("Réponse","success",msg);
                $('#modal-annulation-actes-bulk').modal('hide');
                setTimeout(()=>location.reload(), 1000);
            },
            error: function(xhr){
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de l\'annulation des actes';
                flashAlert("Réponse","error",msg);
            }
        });
    });

    // Ajout du JS pour la confirmation singleton
    $("#btn-confirmer-final").on("click", function(){
        var codeDeclaration = $("#code-declaration-confirmation").val();
        var observation = $("#observation-confirmation").val();
        $.ajax({
            url: "{{ route('acteDeces.confirmer') }}",
            type: 'POST',
            data: {
                code_declaration_deces: codeDeclaration,
                observation: observation,
                _token: '{{ csrf_token() }}'
            },
            success: function(resp){
                if(resp.code == "200"){
                    let msg = Array.isArray(resp.message) ? resp.message[0] : (typeof resp.message === 'object' && resp.message.reponse) ? resp.message.reponse : resp.message;
                    flashAlert("Réponse","success",msg);
                    $('#modal-confirmation-dossier').modal('hide');
                    setTimeout(()=>location.reload(), 1000);
                }else{
                    let msg = Array.isArray(resp.message) ? resp.message[0] : resp.message;
                    flashAlert("Réponse","error",msg);
                }
            },
            error: function(xhr){
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors de la confirmation du dossier';
                flashAlert("Erreur","error",msg);
            }
        });
    });

     // Génération d'actes en lot
     $(document).on("click", "button.generate-actes", function(){
        console.log('Bouton generate-actes cliqué', actesNonGeneres);
        if(actesNonGeneres.length > 0){

            var url = "{{ route('acteDeces.generate.bulk') }}";
            var data = {codes:actesNonGeneres};
            $.post(url,data,function(response){
                console.log(response);
                if(response.code == "200"){
                    $(".over-loader-page").fadeOut(600);
                    flashAlert("Résultat","success",response.message.reponse);
                    $('#modal-generer-single').modal('hide');
                    setTimeout(() => {
                        location.reload();
                    }, 4000);

                }else{
                    $(".over-loader-page").fadeOut(600);
                    //notification("error",response.message);
                    var outString = "<ul>";
                    for (const [key, value] of Object.entries(response.message))
                    {
                    outString+= `<li style='text-align:left;color:red; list-style:disc !important; font-size:12px'>${value}</li>`;
                    }
                    outString += "</ul>";
                    flashAlert("Une erreur est survenue","error",outString);

                }
            });
        }
    return false;
    });

    // Génération d'un acte individuel
    $(document).on("click", ".btn-generer-single", function(){
        var code = $(this).data('id');
        $('#generer-single-code').val(code);
        $('#generer-single-message').html("");
        $('#btn-generer-single-confirm').prop('disabled', false).show();
        $('#modal-generer-single').modal('show');
    });

    $('#btn-generer-single-confirm').on('click', function(){
        var code = $('#generer-single-code').val();
        var url = "{{ route('acteDeces.generate.single') }}";
        $(this).prop('disabled', true);
        $('#generer-single-message').html('<i class="fa fa-spinner fa-spin"></i> Génération en cours...');

        $.post(url, {code_declaration_deces: code, _token: '{{ csrf_token() }}'})
        .done(function(response){
            if(response.code == "200"){
                // Message de succès avec gestion des différents formats de réponse
                let successMessage = response.message;
                if (typeof response.message === 'object' && response.message.reponse) {
                    successMessage = response.message.reponse;
                } else if (Array.isArray(response.message)) {
                    successMessage = response.message[0];
                }

                // Utiliser flashAlert pour le message de succès
                flashAlert("Succès", "success", successMessage);

                // Cacher le modal
                $('#modal-generer-single').modal('hide');

                // Recharger la page après un délai
                setTimeout(() => { location.reload(); }, 1000);
            }else{
                // Message d'erreur avec gestion des différents formats
                let errorMessage = response.message;
                if (typeof response.message === 'object' && response.message.reponse) {
                    errorMessage = response.message.reponse;
                } else if (Array.isArray(response.message)) {
                    errorMessage = response.message[0];
                }

                // Utiliser flashAlert pour le message d'erreur
                flashAlert("Erreur", "error", errorMessage);

                // Réactiver le bouton
                $('#btn-generer-single-confirm').prop('disabled', false);
            }
        })
        .fail(function(xhr){
            let errorMessage = 'Erreur lors de la génération de l\'acte';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            }

            // Utiliser flashAlert pour le message d'erreur
            flashAlert("Erreur", "error", errorMessage);

            // Réactiver le bouton
            $('#btn-generer-single-confirm').prop('disabled', false);
        });
    });

    $(document).on("click", ".btn-retrait-acte", function() {
        var code_acte_deces = $(this).data('id');
        // On suppose que le numéro d'acte et le code_acte_deces sont identiques ici, sinon adapter !
        $("#code_acte").val(code_acte_deces);
        $("#lecode_acte_deces").val(code_acte_deces);
        $("#nom_interesse").val("");
        $("#prenom_interesse").val("");
        $("#telephone_interesse").val("");
        $("#modal-retrait-acte").modal("show");
    });

    $(document).on("click", "#btn-retrait", function(e) {
        e.preventDefault();
        var code_acte_deces = $("#lecode_acte_deces").val();
        var nominteresse = $("#nom_interesse").val();
        var prenominteresse = $("#prenom_interesse").val();
        var telephoneinteresse = $("#telephone_interesse").val();
        if(!nominteresse || !telephoneinteresse) {
            flashAlert("Erreur", "error", "Veuillez renseigner le nom et le téléphone de l'intéressé.");
            return;
        }
        $.ajax({
            url: "{{ route('acteDeces.retrait') }}",
            type: 'POST',
            data: {
                code_acte_deces: code_acte_deces,
                nominteresse: nominteresse,
                prenominteresse: prenominteresse,
                telephoneinteresse: telephoneinteresse,
                _token: '{{ csrf_token() }}'
            },
            success: function(resp) {
                if(resp.code == "200"){
                    $(".over-loader-page").fadeOut(600);
                    flashAlert("Résultat","success",resp.message.reponse);
                    setTimeout(() => {
                        location.reload();
                    }, 1000);

                }else{
                    $(".over-loader-page").fadeOut(600);
                    //notification("error",resp.message);
                    var outString = "<ul>";
                    for (const [key, value] of Object.entries(resp.message))
                    {
                    outString+= `<li style='text-align:left;color:red; list-style:disc !important; font-size:12px'>${value}</li>`;
                    }
                    outString += "</ul>";
                    flashAlert("Une erreur est suvernue","error",outString);
                }
            },
            error: function(xhr) {
                let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Erreur lors du retrait de l\'acte';
                flashAlert("Erreur", "error", msg);
            }
        });
    });

    // Ouvre la modale de validation OTP
    $('.btn-validate-single').on('click', function() {
        var code = $(this).data('id');
        $.post("{{ route('acteDeces.send.otp') }}", {code_declaration_deces: code, _token: '{{ csrf_token() }}'}, function(response){
            if(response.code == "200"){
                // flashAlert("Succès", "success", "Un code de validation a été envoyé par SMS.");
                $('#code_declaration_deces_validate').val(code);
                $('#otp_approbation_pompe_funebre').val('');
                $("#validation_type").val("simple");
                $("#modal-validate-acte").modal('show');
            }else{
                let msg = response.message && response.message.error ? response.message.error : response.message;
                flashAlert("Erreur", "error", msg);
            }
        }).fail(function(xhr){
            let msg = xhr.responseJSON?.message || 'Erreur lors de l\'envoi du code OTP';
            flashAlert("Erreur", "error", msg);
        });
    });
});
</script>
@endsection
